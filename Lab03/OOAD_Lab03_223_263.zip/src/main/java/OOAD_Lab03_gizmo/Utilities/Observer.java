package OOAD_Lab03_gizmo.Utilities;

public interface Observer
{
	void update();
}
